#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include <\Users\sereg\source\repos\Kursach\Kursach\Depo.h>

using namespace std;

int main(int argc, char* argv[])
{
    Depo depo;
    bool alive = true;
    char menu;

    do
    {
        system("cls");

        cout << "1. Load                   2. Save" << endl;
        cout << "3. View                   4. Sort by id" << endl;
        cout << "5. Add                    6. Add to end" << endl;
        cout << "7. Remove                 8. Remove from end" << endl;
        cout << "9. View by city and time  a. Ticket availability" << endl;
        cout << "e. Exit" << endl;

        cout << ">> ";
        cin >> menu;

        switch (menu)
        {
            case '1':
                depo.load();
                break;
            case '2':
                depo.save();
                break;
            case '3':
                depo.view();
                break;
            case '4':
                depo.sort_by_id();
                break;
            case '5':
                depo.add();
                break;
            case '6':
                depo.push_back();
                break;
            case '7':
                depo.remove();
                break;
            case '8':
                depo.pop_back();
                break;
            case '9':
                depo.view_by_city_and_time();
                break;
            case 'a':
                depo.ticket_availability();
                break;
            case 'e':
                alive = false;
                break;
            default:
                cout << "Wrong input" << endl;
                break;
        }

        system("pause");

    } 
    while (alive);

    return 0;
}