#include <string>

class Train
{
    int id;
    char destination[100];
    int minutes;
    int hours;
    int hoursInTravel;
    bool isTicketAvailable;

    public:
        Train();
        Train(int, char*, int, int, int, bool);
        ~Train();
        void input();
        void output(int);
        int getId();
        char* getDestination();
        int getMinutes();
        bool getIsTicketAvailable();
        int getHours();
        int getHoursInTravel();
};