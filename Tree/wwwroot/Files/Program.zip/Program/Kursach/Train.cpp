#include<\Users\sereg\source\repos\Kursach\Kursach\Train.h>
#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

Train::Train()
{
    //ctor
}

Train::~Train()
{
    //dtor
}

void Train::input()
{
    cout << "\n\tTrain id: ";
    cin >> id;

    cout << "\tDestination station: ";
    cin >> destination;

    cout << "\tDeparture time (hours minutes): ";
    cin >> hours >> minutes;

    cout << "\tTravel time (in hours): ";
    cin >> hoursInTravel;

    cout << "\tIs ticket available (1 - true, 0 - false): ";
    cin >> isTicketAvailable;
}

void Train::output(int number)
{
    string time = to_string(hours) + ":" + to_string(minutes);
    string station(destination);
    cout << "|" << number << setw(7 - to_string(number).length()) << "|";
    cout << id << setw(10 - to_string(id).length()) << "|";
    cout << destination << setw(22 - station.length()) << "|";
    cout << time << setw(17 - time.length()) << "|";
    cout << hoursInTravel << setw(18 - to_string(hoursInTravel).length()) << "|";
    cout << (isTicketAvailable == 0 ? "false" : "true") << endl;
    /*cout << "\n\tId: " << id << "\n\tDestination: " << destination <<
        "\n\tDeparture time: " << hours << ":" << minutes <<
        "\n\tHours in travel: " << hoursInTravel << "\n\tTicket available: " <<
        (isTicketAvailable == 0 ? "false" : "true") << endl;*/
}

int Train::getId() 
{
    return id;
}

char* Train::getDestination() 
{
    return destination;
}

int Train::getHours() 
{
    return hours;
}

int Train::getMinutes()
{
    return minutes;
}

bool Train::getIsTicketAvailable() 
{
    return isTicketAvailable;
}

int Train::getHoursInTravel()
{
    return hoursInTravel;
}