#include<\Users\sereg\source\repos\Kursach\Kursach\Train.h>

class Depo
{
    Train* trains;
    int count;
    bool needSort;

    public:
        Depo();
        ~Depo();
        void push_back();
        void pop_back();
        void remove();
        void add();
        void view_by_city_and_time();
        void sort_by_id();
        void ticket_availability();
        void view();
        void resize(int);
        void save();
        void load();
};