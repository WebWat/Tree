#include<\Users\sereg\source\repos\Kursach\Kursach\Depo.h>
#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>

using namespace std;

Depo::Depo()
{
    trains = NULL;
    count = 0;
    needSort = true;
}

Depo::~Depo()
{
    if (trains) 
        delete[] trains;
}

void Depo::resize(int size)
{
    if (trains)
    {
        Train* newtrains = new Train[size];

        for (int i = 0; i < count && i < size; i++)
        {
            newtrains[i] = trains[i];
        }

        delete[] trains;

        trains = newtrains;

        return;
    }

    trains = new Train[size];
}

void Depo::add() 
{
    if (trains == NULL || count <= 0)
    {
        count = 1;
        trains = new Train[count];
        trains[0].input();
    }
    else 
    {
        if (needSort && count > 1) 
        {
            sort_by_id();
            needSort = false;
        }

        int main = 0;
        bool be = false;

        Train train;
        train.input();

        Train* newtrains = new Train[++count];

        int i = 0, j = 0;
        while (i < count)
        {
            if (!be)
            {
                if (i + 1 == count - 1)
                {
                    newtrains[i++] = trains[j++];
                    newtrains[i] = train;
                    break;
                }
                else if (train.getId() <= trains[i].getId())
                {
                    newtrains[i++] = train;
                    be = true;
                }
            }

            newtrains[i++] = trains[j++];
        }

        delete[] trains;

        trains = newtrains;
    }
}

void Depo::sort_by_id() 
{
    Train temp;

    for (int i = 0; i < count - 1; i++)
    {
        for (int j = i + 1; j < count; j++)
        {
            if (trains[i].getId() > trains[j].getId())
            {
                temp = trains[i];
                trains[i] = trains[j];
                trains[j] = temp;
            }
        }
    }

    cout << "\n\tSorted!" << endl;
}

void Depo::push_back()
{
    if (trains == NULL)
    {
        count = 1;
        trains = new Train[count];
        trains[0].input();
    }
    else
    {
        resize(++count);
        trains[count - 1].input();
    }

    needSort = true;
}

void Depo::pop_back()
{
    if (count <= 0) 
        return;
    if (--count > 0)
        resize(count);
    else
        delete[] trains;

    cout << "\n\tDeleted!" << endl;
}

void Depo::view()
{
    if (count == 0)
    {
        cout << "Nothing to view..." << endl;

        return;
    }

    cout << "\n|#     |Id       |Destination          |Departure time  |Hours in travel  |Ticket available" << endl;
    cout << "-------------------------------------------------------------------------------------------" << endl;

    for (int i = 0; i < count; i++)
    {
        trains[i].output(i + 1);
    }

    cout << endl;
}

void Depo::save()
{
    ofstream out("output.bin", ios::binary);

    for (int i = 0; i < count; i++)
    {
        out.write((char*)&trains[i], sizeof(Train));
    }

    out.close();

    cout << "\n\tSaved " << count << " item(s) to output.bin!" << endl;
}

void Depo::load()
{
    ifstream in("output.bin", ios::binary | ios::app);

    in.seekg(0, ios::end);

    count = in.tellg() / sizeof(Train);

    in.seekg(0, ios::beg);

    resize(count);

    for (int i = 0; i < count; i++)
    {
        in.read((char*)&trains[i], sizeof(Train));
    }

    cout << "\tLoad " << count << " item(s) from output.bin"<< endl;

    in.close();
}

void Depo::ticket_availability()
{
    int id;
    bool exist;
    bool find = false;

    cout << "\tEnter train id: ";
    cin >> id;

    for (int i = 0; i < count; i++)
    {
        if (trains[i].getId() == id)
        {
            exist = trains[i].getIsTicketAvailable();
            find = true;
            break;
        }
    }

    if (!find)
    {
        cout << "\n\tTrain with this id is not found!" << endl;

        return;
    }

    if (exist)
        cout << "\n\tTickets are available!" << endl;
    else
        cout << "\n\tTickets are not available" << endl;
}

void Depo::view_by_city_and_time()
{
    int temp;
    int minutes_1 = 0, hours_1 = 0, minutes_2 = 0, hours_2 = 0, inter1, inter2;
    bool find = false;

    string city;

    cout << "\tEnter destination station: ";
    cin >> city;

    cout << "\tInterval (hours1 minutes1 hours2 minutes2): ";
    cin >> hours_1 >> minutes_1 >> hours_2 >> minutes_2;

    inter1 = hours_1 * 60 + minutes_1;
    inter2 = hours_2 * 60 + minutes_2;

    cout << "\n|#     |Id       |Destination          |Departure time  |Hours in travel  |Ticket available" << endl;
    cout << "-------------------------------------------------------------------------------------------" << endl;

    for (int i = 0; i < count; i++)
    {
        string current(trains[i].getDestination());

        temp = trains[i].getHours() * 60 + trains[i].getMinutes();

        if (current == city && (inter1 <= temp && temp <= inter2))
        {
            trains[i].output(i + 1);

            find = true;
        }
    }

    if (!find)
    {
        cout << "\n\tNothing found" << endl;
    }
}

void Depo::remove()
{
    if (count == 0) 
    {
        cout << "\nNothing to delete..." << endl;
        return;
    }

    view();

    int todelete;

    do
    {
        cout << "\tEnter number of element to delete: ";
        cin >> todelete;
    } 
    while (todelete <= 0 || todelete > count);

    if (count == 1) 
    {
        delete[] trains;

        trains = NULL;

        count = 0;
    }
    else 
    {
        Train* newtrains = new Train[count - 1];

        int i = -1;
        int j = 0;

        while (++i < count)
        {
            if (i == todelete - 1)
            {
                continue;
            }

            newtrains[j++] = trains[i];
        }

        delete[] trains;

        trains = newtrains;
        count--;
    }

    cout << "\n\tDeleted!" << endl;
}